/*
 * tcpecho.h
 *
 *  Created on: Nov 10, 2024
 *      Author: hellm
 */

#ifndef APP_TCP_ECHO_H_
#define APP_TCP_ECHO_H_

void tcpecho_init(void);


#endif /* APP_TCP_ECHO_H_ */
